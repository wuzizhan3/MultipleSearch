//
//  ViewController.m
//  Singles' Day
//
//  Created by qf2 on 2016/11/11.
//  Copyright © 2016年 zaoguowangchuan. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,
UISearchBarDelegate,UISearchControllerDelegate>
{
    UITableView         * _tableView;
    NSMutableArray      * _datasourceArray;
    NSMutableArray      * _dataArray;
    NSMutableArray      * _searchResultArray;
    UISearchBar         * _searchBar;
    UIButton            * allbtn;
    BOOL                  isbool;
  //  UISearchController  * _searchController;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _datasourceArray = @[@"川普",@"大幂幂",@"小威威",@"天佑",@"三胖",@"奇异博士",@"余小二",@"阿拉蕾"].mutableCopy;
    _dataArray = @[].mutableCopy;
    [self.view addSubview:[self tableview]];
    [self.view addSubview:[self searchBar]];
    [self.view addSubview:[self allview]];
    // Do any additional setup after loading the view, typically from a nib.
}

- (UISearchBar * )searchBar{
    if (!_searchBar) {
        _searchBar = [[UISearchBar alloc] init];
        _searchBar.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.width/5-44, [UIScreen mainScreen].bounds.size.width, 44);
        _searchBar.placeholder = @"搜索";
        _searchBar.delegate = self;
    }
    return _searchBar;
}

- (UITableView *)tableview{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.width/5, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height - [UIScreen mainScreen].bounds.size.width*2/5)];
        
        _tableView.delegate = self;
        _tableView.dataSource = self;
      //  [_tableView setTableHeaderView:[self searchBar]];
        _tableView.backgroundColor = [UIColor colorWithRed:0.15 green:0.19 blue:0.22 alpha:1.00];
    }
    return _tableView;
    
}

- (UIView*)allview{
    UIView * allview = [UIView new];
    allview.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height - [UIScreen mainScreen].bounds.size.width/5, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.width/5);
    allview.backgroundColor = [UIColor colorWithRed:0.15 green:0.19 blue:0.22 alpha:1.00];
    [self.view addSubview:allview];
    
    allbtn = [UIButton new];
    allbtn.frame = CGRectMake(10, 10, 50, [UIScreen mainScreen].bounds.size.width/5-20);
   
    [allview addSubview:allbtn];
    allbtn.backgroundColor = [UIColor grayColor];
    [allbtn addTarget:self action:@selector(allAction:) forControlEvents:UIControlEventTouchUpInside];
    allbtn.tag = 399;
    
    UILabel * alllabel = [UILabel new];
    [allview addSubview:alllabel];
    alllabel.text = @"全选";
    alllabel.textColor = [UIColor whiteColor];
    alllabel.textAlignment = NSTextAlignmentLeft;
    alllabel.font = [UIFont systemFontOfSize:15];
    alllabel.frame = CGRectMake(CGRectGetMaxX(allbtn.frame) + 10, 10, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.width/5/2+10);
    return allview;
}

#pragma  datesource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (!isbool)
        return _datasourceArray.count;
    else
        return _searchResultArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return [UIScreen mainScreen].bounds.size.width/5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString * cellname = @"cellname";
    UITableViewCell * cell = [tableView cellForRowAtIndexPath:indexPath];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellname];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.contentView.backgroundColor =  [UIColor colorWithRed:0.15 green:0.19 blue:0.22 alpha:1.00];
    }
    
    UIButton * mark = [UIButton new];
    mark.frame = CGRectMake(10, 10, 50, cell.contentView.frame.size.height);
    [cell.contentView addSubview:mark];
    mark.tag = indexPath.row + 300;
    [mark addTarget:self action:@selector(markAction:) forControlEvents:UIControlEventTouchUpInside];

    UILabel * name = [UILabel new];
    name.frame = CGRectMake(CGRectGetMaxX(mark.frame) + 10, 10, cell.contentView.frame.size.width, cell.contentView.frame.size.height);
    name.textAlignment = NSTextAlignmentLeft;
    name.font = [UIFont systemFontOfSize:15];
    name.textColor = [UIColor whiteColor];
    [cell.contentView addSubview:name];
    if (!isbool)
        name.text = _datasourceArray[indexPath.row];
    else
        name.text = _searchResultArray[indexPath.row];
    if ([_dataArray containsObject:name.text])
        mark.backgroundColor = [UIColor redColor];
    else
        mark.backgroundColor =[UIColor grayColor];
    
    return cell;
}

-(void)searchBar:(UISearchBar*)searchBar textDidChange:(NSString*)text
{
    //NSLog(@"searchBar ... text.length: %d", text.length);
    
    if(text.length == 0)
    {
        isbool = NO;
    }
    else
    {
        isbool = YES;
        _searchResultArray = [[NSMutableArray alloc] init];
        for (NSString * item in _datasourceArray)
        {
            
            //case insensative search - way cool
            if ([item rangeOfString:text options:NSCaseInsensitiveSearch | NSDiacriticInsensitiveSearch].location != NSNotFound)
            {
                [_searchResultArray addObject:item];
            }
            
        }
    }//end if-else
    
    [_tableView reloadData];
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [searchBar resignFirstResponder];    
}

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    [searchBar setShowsCancelButton:YES animated:YES];
}
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    searchBar.text=@"";
    isbool= NO;
    [searchBar setShowsCancelButton:NO animated:YES];
    [searchBar resignFirstResponder];
    [_tableView reloadData];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 单选
 */
- (void)markAction:(UIButton *)sender{
    NSString * stringtag;
    
    if (_searchBar.text.length>0 && _searchResultArray.count>0) {
        stringtag = _searchResultArray[sender.tag-300];
    }else{
        stringtag  = _datasourceArray[sender.tag - 300];
        
    }
    
    if (![_dataArray containsObject:stringtag]) {
        [_dataArray addObject:stringtag];
        sender.backgroundColor = [UIColor redColor];
    }else{
        sender.backgroundColor = [UIColor grayColor];
        [_dataArray removeObject:stringtag];
    }
    
    if ((_dataArray.count != _datasourceArray.count && allbtn.tag ==400)) {
        allbtn.tag = 399;
        allbtn.backgroundColor = [UIColor grayColor];
    }else if (_dataArray.count == _datasourceArray.count && allbtn.tag ==399){
        allbtn.backgroundColor = [UIColor redColor];
        allbtn.tag = 400;
    }
}

/*
 全部选择
 */
- (void)allAction:(UIButton *)sender{
    
    if (sender.tag == 399) {
        sender.backgroundColor = [UIColor redColor];
        sender.tag = 400;
        
        [_dataArray removeAllObjects];
        for (NSInteger i = 0; i<_datasourceArray.count; i++) {
            NSString * stringtag = _datasourceArray[i];
            UITableViewCell * cell = [_tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];

            UIButton * mark = (UIButton *)[cell viewWithTag:i+300];
            
            mark.backgroundColor = [UIColor redColor];
            
            [_dataArray addObject:stringtag];
        }
    }else{
        sender.backgroundColor = [UIColor grayColor];
        sender.tag = 399;
        
        for (NSInteger i = 0; i<_datasourceArray.count; i++) {
            UITableViewCell * cell = [_tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
            UIButton * mark = (UIButton *)[cell viewWithTag:i+300];
            mark.backgroundColor = [UIColor grayColor];
            
        }
        [_dataArray removeAllObjects];
    }
    
    
}
@end
