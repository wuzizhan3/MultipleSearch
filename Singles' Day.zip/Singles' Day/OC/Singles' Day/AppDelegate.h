//
//  AppDelegate.h
//  Singles' Day
//
//  Created by qf2 on 2016/11/11.
//  Copyright © 2016年 zaoguowangchuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

