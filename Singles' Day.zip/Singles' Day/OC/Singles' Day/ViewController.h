//
//  ViewController.h
//  Singles' Day
//
//  Created by qf2 on 2016/11/11.
//  Copyright © 2016年 zaoguowangchuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

typedef void (^blockcool)(NSString * string);

@property (nonatomic , strong) blockcool  cool;

- (void)blocktheValue:( blockcool)string;
@end

