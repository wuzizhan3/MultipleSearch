//
//  ViewController.swift
//  Singles' Day
//
//  Created by qf2 on 2016/11/14.
//  Copyright © 2016年 zaoguowangchuan. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate {

    let _tableView = UITableView()
    let ScreenWith = UIScreen.main.bounds.size.width
    let ScreenHeigth = UIScreen.main.bounds.size.height
    var datasourceArray = NSMutableArray()
    var dataArray = NSMutableArray()
    var searchResuleArray = NSMutableArray()
    let searchbar = UISearchBar()
    var isbool = Bool()
    let allbtn = UIButton()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        datasourceArray = NSMutableArray.init(array: ["小明","小王","小李子","小赵","小钱","小周","小吴"])
        createsearchbar()
        createtableview()
        self.view.addSubview(createboomview())
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func createsearchbar() -> Void {
        searchbar.frame = CGRect.init(x: 0, y: 20, width: ScreenWith, height: 44)
        searchbar.placeholder = "搜索"
        searchbar.delegate = self
        self.view.addSubview(searchbar)
    }

    func createtableview() -> Void{
        _tableView.frame = CGRect.init(x: 0, y: 64, width: ScreenWith, height: ScreenHeigth-64-ScreenWith/5)
        _tableView.delegate = self
        _tableView.dataSource = self
        _tableView.tableFooterView = UIView.init()
        self.view.addSubview(_tableView)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isbool {
            return searchResuleArray.count
        }else{
            return datasourceArray.count
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return ScreenWith/5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellname : NSString = "cellname"
        
        let cell  = UITableViewCell.init(style:UITableViewCellStyle.default, reuseIdentifier: cellname as String)
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        
        let markbtn = UIButton()
        markbtn.frame = CGRect.init(x: 10, y: 10, width: ScreenWith/5-20, height: ScreenWith/5-20)
        markbtn.backgroundColor = UIColor.gray
        cell.contentView.addSubview(markbtn)
        markbtn.tag = indexPath.row + 300
        markbtn.addTarget(self, action:#selector(markAction(sender:)), for: UIControlEvents.touchUpInside)
        
        let title = UILabel()
        title.frame = CGRect.init(x: markbtn.frame.size.width + markbtn.frame.origin.x + 10, y: 20, width: 100, height: 20)
        title.font = UIFont.systemFont(ofSize: 13)
        title.textColor = UIColor.black
        cell.contentView.addSubview(title)
        if isbool {
            title.text = searchResuleArray[indexPath.row] as? String
        }else{
            title.text = datasourceArray[indexPath.row] as? String
        }
        
        if dataArray.contains(title.text!) {
            markbtn.backgroundColor = UIColor.red
        }else{
            markbtn.backgroundColor = UIColor.gray
        }
        
        return cell
    }
    /*
        单选
     */
    func markAction(sender :UIButton) -> Void {
        
        sender.backgroundColor = UIColor.red
        var  string = NSString()
        if searchbar.text!.characters.count>0 && searchResuleArray.count>0{
            string = searchResuleArray[sender.tag-300] as! NSString
        }else{
            string = datasourceArray[sender.tag-300] as! NSString
        }
        
        if dataArray.contains(string) {
            sender.backgroundColor = UIColor.gray
            dataArray.remove(string)
        }else{
            sender.backgroundColor = UIColor.red
            dataArray.add(string)
        }
        
        if dataArray.count != datasourceArray.count && allbtn.tag == 400 {
            allbtn.tag = 399
            allbtn.backgroundColor = UIColor.gray
        }
       else if dataArray.count == datasourceArray.count && allbtn.tag == 399 {
            allbtn.tag = 400
            allbtn.backgroundColor = UIColor.red
        }
        
        let  alert = UIAlertController.init(title: "提示", message: "sdsd", preferredStyle: .alert)
        alert.addAction(UIAlertAction.init(title: "sdd", style: .default, handler: { (UIAlertAction)->Void in
            
        }))
       /// present(alert, animated: true, completion: nil)
        
    }
    /// searchbar delegate
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchBar.text?.characters.count == 0 {
            isbool  = false
        }else{
            isbool = true
            searchResuleArray = NSMutableArray()
            for num in 0 ..< datasourceArray.count {
                let item : NSString = datasourceArray[num] as! NSString
                let rang : NSRange = item.range(of: searchText, options: .diacriticInsensitive)
                
                
                if rang.location != NSNotFound {
                    searchResuleArray.add(item)
                }
                
            }
            
        }
        _tableView.reloadData()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchbar.resignFirstResponder()
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchbar.showsCancelButton = true
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchbar.text = ""
        isbool = false
        searchbar.showsCancelButton = false
        searchbar.resignFirstResponder()
        _tableView.reloadData()
    }
    
    func createboomview() -> UIView {
        let boomview = UIView()
        boomview.frame = CGRect.init(x: 0, y: _tableView.frame.size.height + _tableView.frame.origin.y , width: ScreenWith, height: ScreenWith/5)
        boomview.backgroundColor = UIColor.gray
        
        
        allbtn.frame = CGRect.init(x: 10, y: 10, width: ScreenWith/5-20, height: ScreenWith/5-20)
        allbtn.backgroundColor = UIColor.gray
        allbtn.tag = 399
        allbtn.addTarget(self, action: #selector(allAction(sender:)), for: UIControlEvents.touchUpInside)
        
        let title = UILabel()
        title.frame = CGRect.init(x: allbtn.frame.size.width + allbtn.frame.origin.x + 10, y: 20, width: 100, height: 20)
        title.font = UIFont.systemFont(ofSize: 13)
        title.textColor = UIColor.black
        title.text = "全选"
        
        boomview.addSubview(allbtn)
        boomview.addSubview(title)
        
        return boomview
    }
    
    func allAction(sender : UIButton) -> Void {
        if sender.tag == 399 {
            sender.tag = 400
            sender.backgroundColor = UIColor.red
            dataArray.removeAllObjects()
            for num in 0 ..< datasourceArray.count {
                let string : NSString = datasourceArray[num] as! NSString
                
                dataArray.add(string)
                
                let cell : UITableViewCell = _tableView.cellForRow(at: NSIndexPath.init(row: num, section: 0) as IndexPath)!
                let mark : UIButton = cell.viewWithTag(num + 300) as! UIButton
                mark.backgroundColor = UIColor.red
                
            }
        }else{
           sender.tag = 399
            sender.backgroundColor = UIColor.gray
            for num in 0 ..< datasourceArray.count {
                let cell : UITableViewCell = _tableView.cellForRow(at: NSIndexPath.init(row: num, section: 0)as IndexPath)!
                
                let mark : UIButton = cell.viewWithTag(num+300) as! UIButton
                mark.backgroundColor = UIColor.gray
                
                
            }
            dataArray.removeAllObjects()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

